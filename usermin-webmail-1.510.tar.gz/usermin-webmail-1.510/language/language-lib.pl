# language-lib.pl

BEGIN { push(@INC, ".."); };
use WebminCore;
&init_config();

1;

